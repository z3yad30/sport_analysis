library(dplyr)

argentina_passes <- passes |>
  filter(
    match_label == "Argentina vs Croatia",
    team_name == "Argentina",
    is.na(pass_outcome_name) | pass_outcome_name == "",
    !is.na(player_name),
    !is.na(pass_recipient_name),
    !is.na(x),
    !is.na(y),
    !is.na(end_x),
    !is.na(end_y)
  )

argentina_edges <- argentina_passes |>
  count(
    from = player_name,
    to = pass_recipient_name,
    name = "passes",
    sort = TRUE
  )

argentina_nodes <- bind_rows(
  argentina_passes |>
    transmute(
      player = player_name,
      x = x,
      y = y
    ),
  argentina_passes |>
    transmute(
      player = pass_recipient_name,
      x = end_x,
      y = end_y
    )
) |>
  group_by(player) |>
  summarise(
    x = median(x, na.rm = TRUE),
    y = median(y, na.rm = TRUE),
    involvements = n(),
    .groups = "drop"
  )

argentina_edges_xy <- argentina_edges |>
  left_join(
    argentina_nodes |>
      select(
        from = player,
        x_start = x,
        y_start = y
      ),
    by = "from"
  ) |>
  left_join(
    argentina_nodes |>
      select(
        to = player,
        x_end = x,
        y_end = y
      ),
    by = "to"
  ) |>
  filter(
    !is.na(x_start),
    !is.na(y_start),
    !is.na(x_end),
    !is.na(y_end)
  )

print(argentina_edges, n = Inf)

