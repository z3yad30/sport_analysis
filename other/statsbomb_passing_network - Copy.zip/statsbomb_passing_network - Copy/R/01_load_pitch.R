library(sf)

pitch_directory <- "C:/Users/ahmed/Desktop/football_assets/statsbomb_pitch/shapefiles"

pitch_surface <- st_read(
  file.path(pitch_directory, "statsbomb_pitch_surface.shp"),
  quiet = TRUE
)

pitch_lines <- st_read(
  file.path(pitch_directory, "statsbomb_pitch_lines.shp"),
  quiet = TRUE
)

pitch_spots <- st_read(
  file.path(pitch_directory, "statsbomb_pitch_spots.shp"),
  quiet = TRUE
)
st_crs(pitch_surface) <- NA
st_crs(pitch_lines) <- NA
st_crs(pitch_spots) <- NA