library(ggplot2)
library(dplyr)
library(ggrepel)

source("R/01_load_pitch.R")
source("R/03_load_pass_data.R")
source("R/06_prepare_argentina_network.R")

min_passes <- 3

plot_edges <- argentina_edges_xy |>
  filter(passes >= min_passes)

plot_players <- unique(c(plot_edges$from, plot_edges$to))

plot_nodes <- argentina_nodes |>
  filter(player %in% plot_players) |>
  mutate(
    label = case_when(
      player == "Lionel Andrés Messi Cuccittini" ~ "Messi",
      player == "Damián Emiliano Martínez" ~ "E. Martínez",
      player == "Lisandro Martínez" ~ "L. Martínez",
      player == "Nahuel Molina Lucero" ~ "N. Molina",
      TRUE ~ sub(".* ", "", player)
    )
  )

argentina_network_plot <- ggplot() +
  
  # Pitch
  geom_sf(
    data = pitch_surface,
    fill = "#1F5F3B",
    colour = NA
  ) +
  
  geom_sf(
    data = pitch_lines,
    colour = alpha("white", 0.55),
    linewidth = 0.45
  ) +
  
  geom_sf(
    data = pitch_spots,
    colour = alpha("white", 0.65),
    size = 0.9
  ) +
  
  # Passing connections
  geom_curve(
    data = plot_edges,
    aes(
      x = x_start,
      y = y_start,
      xend = x_end,
      yend = y_end,
      linewidth = passes,
      alpha = passes
    ),
    colour = "#D8B44A",
    curvature = 0.08,
    lineend = "round",
    arrow = grid::arrow(
      length = grid::unit(0.055, "inches"),
      type = "closed"
    )
  ) +
  
  # Player nodes
  geom_point(
    data = plot_nodes,
    aes(
      x = x,
      y = y,
      size = involvements
    ),
    shape = 21,
    fill = "#F4F1EA",
    colour = "#111111",
    stroke = 0.45
  ) +
  
  # Player labels
  ggrepel::geom_text_repel(
    data = plot_nodes,
    aes(
      x = x,
      y = y,
      label = label
    ),
    colour = "#111111",
    size = 3.1,
    fontface = "bold",
    box.padding = 0.25,
    point.padding = 0.15,
    segment.colour = alpha("white", 0.35),
    segment.linewidth = 0.25,
    min.segment.length = 0,
    seed = 7,
    max.overlaps = Inf
  ) +
  
  scale_linewidth_continuous(
    name = "Completed passes",
    range = c(0.25, 1.7),
    breaks = c(4, 6, 8, 10)
  ) +
  
  scale_alpha_continuous(
    range = c(0.30, 0.80),
    guide = "none"
  ) +
  
  scale_size_continuous(
    name = "Pass involvement",
    range = c(3.0, 6.5),
    breaks = c(20, 40, 60, 80)
  ) +
  
  coord_sf(
    xlim = c(0, 120),
    ylim = c(0, 80),
    expand = FALSE,
    datum = NA
  ) +
  
  labs(
    title = "Argentina passing network",
    subtitle = "Croatia 0–3 Argentina | FIFA World Cup semi-final, 2022",
    caption = paste0(
      "Completed passes only · Minimum ",
      min_passes,
      " passes per connection"
    )
  ) +
  
  theme_void(base_family = "sans") +
  
  theme(
    plot.background = element_rect(fill = "#F7F5EF", colour = NA),
    panel.background = element_rect(fill = "#F7F5EF", colour = NA),
    
    plot.title = element_text(
      face = "bold",
      size = 18,
      colour = "#111111",
      margin = margin(b = 3)
    ),
    
    plot.subtitle = element_text(
      size = 10.5,
      colour = "#444444",
      margin = margin(b = 10)
    ),
    
    plot.caption = element_text(
      size = 8,
      colour = "#666666",
      hjust = 1,
      margin = margin(t = 8)
    ),
    
    legend.position = "right",
    legend.title = element_text(
      size = 9,
      face = "bold",
      colour = "#222222"
    ),
    legend.text = element_text(
      size = 8,
      colour = "#333333"
    ),
    legend.key = element_rect(fill = "#F7F5EF", colour = NA),
    legend.background = element_rect(fill = "#F7F5EF", colour = NA),
    
    plot.margin = margin(12, 18, 10, 12)
  )

print(argentina_network_plot)