library(dplyr)

# ------------------------------------------
# Settings
# ------------------------------------------
team_to_plot  <- "Argentina"
match_to_plot <- "Argentina vs Croatia"
top_n_players <- 5

# ------------------------------------------
# Keep all qualifying forward attacking passes
# ------------------------------------------
attacking_forward_passes <- passes |>
  filter(
    match_label == match_to_plot,
    team_name == team_to_plot,
    type_name == "Pass",
    !is.na(player_name),
    !is.na(x),
    !is.na(y),
    !is.na(end_x),
    !is.na(end_y)
  ) |>
  mutate(
    completed = is.na(pass_outcome_name) | pass_outcome_name == "",
    forward_distance = end_x - x,
    forward_pass = forward_distance >= 10,
    attacking_zone = x >= 40,
    key_pass = dplyr::coalesce(pass_shot_assist, FALSE),
    goal_assist = dplyr::coalesce(pass_goal_assist, FALSE),
    pass_type = case_when(
      goal_assist ~ "Goal assist",
      key_pass ~ "Shot assist",
      completed ~ "Completed",
      TRUE ~ "Incomplete"
    )
  ) |>
  filter(
    forward_pass,
    attacking_zone
  )

# ------------------------------------------
# Top 5 players by number of qualifying forward passes
# ------------------------------------------
top_players <- attacking_forward_passes |>
  count(player_name, name = "forward_passes", sort = TRUE) |>
  slice_head(n = top_n_players) |>
  mutate(
    short_name = case_when(
      player_name == "Lionel Andrés Messi Cuccittini" ~ "Messi",
      player_name == "Rodrigo Javier De Paul" ~ "De Paul",
      player_name == "Leandro Daniel Paredes" ~ "Paredes",
      player_name == "Enzo Fernandez" ~ "Fernandez",
      player_name == "Cristian Gabriel Romero" ~ "Romero",
      player_name == "Nahuel Molina Lucero" ~ "Molina",
      player_name == "Ángel Fabián Di María Hernández" ~ "Di María",
      player_name == "Alexis Mac Allister" ~ "Mac Allister",
      player_name == "Julián Álvarez" ~ "Álvarez",
      player_name == "Nicolás Hernán Gonzalo Otamendi" ~ "Otamendi",
      player_name == "Lisandro Martínez" ~ "L. Martínez",
      player_name == "Damián Emiliano Martínez" ~ "E. Martínez",
      TRUE ~ sub(".* ", "", player_name)
    )
  )

# ------------------------------------------
# Label only passes made by the top 5 players
# One row = one pass by a top-5 player
# Label is placed near the middle of the arrow, slightly below it
# ------------------------------------------
label_passes <- attacking_forward_passes |>
  inner_join(
    top_players |>
      select(player_name, short_name, forward_passes),
    by = "player_name"
  ) |>
  mutate(
    label_x = x,
    label_y = y - 1.2
  )
# ------------------------------------------
# Left-side summary block text
# ------------------------------------------
summary_text <- paste0(
  "Top ", top_n_players, " forward passers\n",
  paste0(
    top_players$short_name,
    " — ",
    top_players$forward_passes,
    collapse = "\n"
  )
)

print(top_players, n = Inf)