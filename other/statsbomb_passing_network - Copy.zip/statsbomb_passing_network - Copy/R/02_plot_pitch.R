library(ggplot2)

pitch_plot <- ggplot() +
  geom_sf(
    data = pitch_surface,
    fill = "#2E7D32",
    colour = NA
  ) +
  geom_sf(
    data = pitch_lines,
    colour = "white",
    linewidth = 0.7
  ) +
  geom_sf(
    data = pitch_spots,
    colour = "white",
    size = 1.8
  ) +
  coord_sf(
    xlim = c(0, 120),
    ylim = c(0, 80),
    expand = FALSE,
    datum = NA
  ) +
  theme_void()

print(pitch_plot)