library(ggplot2)
library(dplyr)
library(ggrepel)

source("R/01_load_pitch.R")
source("R/03_load_pass_data.R")
source("R/08_prepare_attacking_forward_passes.R")

attacking_forward_pass_plot <- ggplot() +
  
  # Pitch
  geom_sf(
    data = pitch_surface,
    fill = "#F7F5EF",
    colour = NA
  ) +
  
  geom_sf(
    data = pitch_lines,
    colour = "#7A6655",
    linewidth = 0.45
  ) +
  
  geom_sf(
    data = pitch_spots,
    colour = "#7A6655",
    size = 0.9
  ) +
  
  # All qualifying forward passes
  geom_segment(
    data = attacking_forward_passes,
    aes(
      x = x,
      y = y,
      xend = end_x,
      yend = end_y,
      colour = pass_type,
      linewidth = pass_type,
      alpha = pass_type
    ),
    arrow = grid::arrow(
      length = grid::unit(0.06, "inches"),
      type = "closed"
    ),
    lineend = "round"
  ) +
  
  # Names only for passes made by top 5 players
  geom_text(
    data = label_passes,
    aes(
      x = label_x,
      y = label_y,
      label = short_name
    ),
    colour = "#111111",
    size = 2.8,
    fontface = "bold",
    vjust = 1
  ) +
  
  # Left-side summary block
  annotate(
    "text",
    x = -16,
    y = 78,
    label = summary_text,
    hjust = 0,
    vjust = 1,
    size = 3.5,
    fontface = "bold",
    colour = "#111111",
    family = "mono"
  ) +
  
  scale_colour_manual(
    name = NULL,
    values = c(
      "Incomplete" = "grey75",
      "Completed" = "#1F5EFF",
      "Shot assist" = "#F39C12",
      "Goal assist" = "#D7191C"
    )
  ) +
  
  scale_linewidth_manual(
    name = NULL,
    values = c(
      "Incomplete" = 0.35,
      "Completed" = 0.55,
      "Shot assist" = 1.00,
      "Goal assist" = 1.25
    )
  ) +
  
  scale_alpha_manual(
    name = NULL,
    values = c(
      "Incomplete" = 0.35,
      "Completed" = 0.75,
      "Shot assist" = 0.90,
      "Goal assist" = 1.00
    )
  ) +
  
  coord_sf(
    xlim = c(-18, 120),
    ylim = c(0, 80),
    expand = FALSE,
    datum = NA
  ) +
  
  labs(
    title = paste0(team_to_plot, " attacking forward passes"),
    subtitle = paste0(match_to_plot, " | All forward passes, top 5 passers labelled"),
    caption = "Forward attacking pass = starts at x >= 40 and moves at least 10 units toward goal"
  ) +
  
  theme_void(base_family = "sans") +
  
  theme(
    plot.background = element_rect(fill = "#F7F5EF", colour = NA),
    panel.background = element_rect(fill = "#F7F5EF", colour = NA),
    
    plot.title = element_text(
      face = "bold",
      size = 18,
      colour = "#111111",
      margin = margin(b = 3)
    ),
    
    plot.subtitle = element_text(
      size = 10.5,
      colour = "#444444",
      margin = margin(b = 10)
    ),
    
    plot.caption = element_text(
      size = 8,
      colour = "#666666",
      hjust = 1,
      margin = margin(t = 8)
    ),
    
    legend.position = "bottom",
    legend.text = element_text(
      size = 8,
      colour = "#333333"
    ),
    
    plot.margin = margin(12, 18, 10, 12)
  )

print(attacking_forward_pass_plot)