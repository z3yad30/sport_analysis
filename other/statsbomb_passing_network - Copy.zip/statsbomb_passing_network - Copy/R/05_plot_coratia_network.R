library(ggplot2)
library(dplyr)

source("R/01_load_pitch.R")
source("R/03_load_pass_data.R")
source("R/04_prepare_coratia_network.R")

# Raise this if the plot is too crowded.
min_passes <- 3

plot_edges <- croatia_edges_xy |>
  filter(passes >= min_passes)

plot_players <- unique(
  c(
    plot_edges$from,
    plot_edges$to
  )
)

plot_nodes <- croatia_nodes |>
  filter(player %in% plot_players) |>
  mutate(
    label = sub(".* ", "", player)
  )

croatia_network_plot <- ggplot() +
  
  # Pitch
  geom_sf(
    data = pitch_surface,
    fill = "#2E7D32",
    colour = NA
  ) +
  
  geom_sf(
    data = pitch_lines,
    colour = "white",
    linewidth = 0.7
  ) +
  
  geom_sf(
    data = pitch_spots,
    colour = "white",
    size = 1.5
  ) +
  
  # Passing connections
  geom_curve(
    data = plot_edges,
    aes(
      x = x_start,
      y = y_start,
      xend = x_end,
      yend = y_end,
      linewidth = passes
    ),
    colour = "#FFD54F",
    curvature = 0.12,
    alpha = 0.75,
    arrow = grid::arrow(
      length = grid::unit(0.12, "inches"),
      type = "closed"
    )
  ) +
  
  # Player nodes
  geom_point(
    data = plot_nodes,
    aes(
      x = x,
      y = y,
      size = involvements
    ),
    shape = 21,
    fill = "white",
    colour = "black",
    stroke = 0.8
  ) +
  
  # Player labels
  geom_text(
    data = plot_nodes,
    aes(
      x = x,
      y = y,
      label = label
    ),
    colour = "black",
    fontface = "bold",
    size = 3.3,
    vjust = -1.3
  ) +
  
  scale_linewidth_continuous(
    name = "Completed passes",
    range = c(0.5, 3)
  ) +
  
  scale_size_continuous(
    name = "Pass involvement",
    range = c(4, 8)
  ) +
  
  coord_sf(
    xlim = c(0, 120),
    ylim = c(0, 80),
    expand = FALSE,
    datum = NA
  ) +
  
  labs(
    title = "Croatia passing network",
    subtitle = "Croatia vs Argentina — 2022 World Cup semi-final",
    caption = paste0(
      "Completed passes only | Minimum ",
      min_passes,
      " passes per connection"
    )
  ) +
  
  theme_void() +
  
  theme(
    plot.title = element_text(
      face = "bold",
      size = 18
    ),
    plot.subtitle = element_text(
      size = 12
    ),
    plot.caption = element_text(
      size = 9
    ),
    legend.position = "right"
  )

print(croatia_network_plot)