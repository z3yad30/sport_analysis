library(readr)

passes <- read_csv(
  "data/raw/football_map_separated/world_cup/passes.csv",
  show_col_types = FALSE
)