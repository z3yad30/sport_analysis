library(tidyverse)

# Set this to the unzipped folder path.
DATA_DIR <- "football_map_separated"

load_competition <- function(folder) {
  list(
    shots = read_csv(file.path(DATA_DIR, folder, "shots.csv"), show_col_types = FALSE),
    crosses = read_csv(file.path(DATA_DIR, folder, "crosses.csv"), show_col_types = FALSE),
    passes = read_csv(file.path(DATA_DIR, folder, "passes.csv"), show_col_types = FALSE),
    pressure = read_csv(file.path(DATA_DIR, folder, "pressure.csv"), show_col_types = FALSE)
  )
}

pitch <- function() {
  ggplot() +
    xlim(0, 120) + ylim(0, 80) + coord_fixed() +
    annotate("rect", xmin = 0, xmax = 120, ymin = 0, ymax = 80, fill = NA, colour = "black") +
    annotate("segment", x = 60, xend = 60, y = 0, yend = 80, colour = "black") +
    annotate("rect", xmin = 0, xmax = 18, ymin = 18, ymax = 62, fill = NA, colour = "black") +
    annotate("rect", xmin = 102, xmax = 120, ymin = 18, ymax = 62, fill = NA, colour = "black") +
    annotate("rect", xmin = 0, xmax = 6, ymin = 30, ymax = 50, fill = NA, colour = "black") +
    annotate("rect", xmin = 114, xmax = 120, ymin = 30, ymax = 50, fill = NA, colour = "black") +
    theme_void()
}

plot_shots <- function(shots, team_filter = NULL) {
  d <- shots %>% filter(start_coord_in_pitch_0_120_0_80 == TRUE)
  if (!is.null(team_filter)) d <- d %>% filter(team_name == team_filter)
  pitch() +
    geom_point(data = d, aes(x = x, y = y, size = shot_statsbomb_xg, shape = shot_outcome_name), alpha = 0.75) +
    facet_grid(stage ~ match_label) +
    labs(title = "Shot locations", size = "xG", shape = "Outcome")
}

plot_arrows <- function(events, title, team_filter = NULL) {
  d <- events %>% filter(start_coord_in_pitch_0_120_0_80 == TRUE, end_coord_in_pitch_0_120_0_80 == TRUE)
  if (!is.null(team_filter)) d <- d %>% filter(team_name == team_filter)
  pitch() +
    geom_segment(data = d, aes(x = x, y = y, xend = end_x, yend = end_y),
                 arrow = arrow(length = unit(0.08, "inches")), alpha = 0.45) +
    facet_grid(stage ~ match_label) +
    labs(title = title)
}

plot_pressure <- function(pressure, team_filter = NULL) {
  d <- pressure %>% filter(start_coord_in_pitch_0_120_0_80 == TRUE)
  if (!is.null(team_filter)) d <- d %>% filter(team_name == team_filter)
  pitch() +
    geom_point(data = d, aes(x = x, y = y), alpha = 0.35) +
    facet_grid(stage ~ match_label) +
    labs(title = "Pressure locations")
}

# Examples:
afcon <- load_competition("afcon")
world_cup <- load_competition("world_cup")

# plot_shots(afcon$shots)
# plot_arrows(afcon$passes, "AFCON pass locations")
# plot_arrows(afcon$crosses, "AFCON cross locations")
# plot_pressure(afcon$pressure)
# plot_shots(world_cup$shots, "Argentina")
