# Separated football map datasets

Folder structure requested:
- afcon/shots.csv, crosses.csv, passes.csv, pressure.csv
- world_cup/shots.csv, crosses.csv, passes.csv, pressure.csv

Each competition folder also includes match_lookup.csv so you can filter semi-finals vs final by match_id/stage.

Coordinate notes:
- x/y are split numeric event-location columns for R mapping.
- passes.csv and crosses.csv include end_x/end_y for arrows.
- shots.csv includes end_x/end_y/end_z where available; shot end locations may include z height.
- pressure.csv has x/y only. Pressure events do not have end_x/end_y because they are not start-to-end actions.

Accuracy caveat:
These are event/action locations in a StatsBomb-style 120 x 80 pitch coordinate system. They are suitable for event maps, not exact player tracking or GPS movement.
